const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config.json');
const wait = require('node:timers/promises').setTimeout;

module.exports = {
	/*name: Events.MessageCreate,
	once: false,
    async execute(channel, connection) {

    },*/
};